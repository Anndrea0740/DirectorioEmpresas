<?php
     include_once("../Utilerias/db.php");
     $post = $_POST; // 
     if ($post['boton']=="Agregar")
     {
          $res = agregaEmpresa($post);
          $post["pk"]= $res;
          $response['status'] = true;
          $response['data'] = $post;
          echo json_encode($response);
     } else if ($post['boton']=="Actualizar")
            {
               if (actualizaEmpresa($post)){
                    $response['status']= true;
                    $response['data']=$post;
                 }
                 else{
                    $response['status']= false;
                    $response['data']=$post;
                 }
                 echo json_encode($response);
            } else if ($post['boton']=="Borrar")
            {
                 if (borraEmpresa($post)){
                    $response['status']= true;
                    $response['data']=$post;
                 }
                 else{
                    $response['status']= false;
                    $response['data']=$post;
                 }
                 echo json_encode($response);
            }
?>