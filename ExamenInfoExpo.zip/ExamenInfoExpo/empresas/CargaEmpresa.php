<?php
    include_once('../Utilerias/db.php');
    $cursos = cargaCursos();
    foreach ($cursos as $tupla )
    {
        echo "<tr id='". $tupla['idEmpresa'] . "'>
            <td>" . $tupla['rutEmpresa'] . "</td>
            <td>" . $tupla['acronimoEmpresa'] . "</td>
            <td>" . $tupla['direccionEmpresa'] . "</td>
            <td>" . $tupla['regionEmpresa'] . "</td>
            <td>" . $tupla['ciudadEmpresa'] . "</td>
            <td>" . $tupla['emailEmpresa'] . "</td>
            <td>" . $tupla['telefonoEmpresa'] . "</td>
                
            <td>
                <i class='material-icons edit' id-record='" . $tupla['idEmpresa'] . "'>create</i>
                <i class='material-icons delete' id-record='". $tupla['idEmpresa'] . "'>delete_forever</i>
            </td>
        </tr>";
    } 
?>