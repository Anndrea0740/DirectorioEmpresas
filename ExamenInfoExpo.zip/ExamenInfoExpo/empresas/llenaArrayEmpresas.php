<?php
    include_once("../Utilerias/db.php");
    
    $cur = cargaEmpresa();
    $data=array();
    $response=array();
    $response['status']=1;
    $response['data']=array();
    foreach ($cur as $tupla)
    {
        $data[$tupla['idEmpresa']]=$tupla;
    }
    $response['data']=$data;
    echo json_encode($response);
?>