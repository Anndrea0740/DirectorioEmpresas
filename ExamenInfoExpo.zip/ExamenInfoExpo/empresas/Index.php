<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="../css/dataTables.materialize.css"/>
    <link type="text/css" rel="stylesheet" href="../css/default.css"/>
    <link type="text/css" rel="stylesheet" href="../css/clase.css"/>
    <link rel="icon" type="image/x-icon" href="../fonts/favicon.ico" />
</head>
<body>
<?php include_once("../resources/html/header.php");
          include_once("../Utilerias/db.php");
          if  (!isset($_SESSION))
            session_start();   
            //echo "<h1>Validando Tu y idsess</h1>" .  $_SESSION["email"]; 
                $idSess = session_id();
               // echo "<h1>Validando Tu y idSess</h1>" . $idSess;
                $tu = $_SESSION["tu"];
                $correo = $_SESSION["email"];
                $idsess = "";
                validaSess($correo, $tu, $idsess);
                //echo "<h1>idsess</h1>" . $idsess;
                //echo "<h1>tu</h1>" . $tu;
                if ($idsess == $idSess && $tu == 52)
                {
                    $_SESSION["tu"]=$tu;
                    $_SESSION["email"]=$correo;
                    $_SESSION["ids"]=$idSess;
                    $response['status']= true;
                }
                else
                {
                    header("location:http://localhost/ExamenInfoExpo/Inicio");
                }
    ?>
   
    <div class="row" id="antesllenartabla">
        <div class="col s12 m8 offset-m2">
            <div class="card" id="dondetabla">
                <a id="add-record" class="btn-floating btn-large waves-effect waves-light right" >
                    <i class="material-icons">add</i>
                </a>
               
                <a id="print-record" class="btn-floating btn-large waves-effect waves-light right" >
                    <i class="material-icons">local_printshop</i>
                </a>
                <div class="card-content">
                    <span><h3>Registro de Empresas</h3></span>
                    <table id="cur" class="highlight bordered dataTable">
                        <thead>
                           <tr><th>Rut Empresa</th><th>Acronimo Empresa</th><th>Direccion Empresa</th><th>Region Empresa</th><th>Ciudad Empresa</th><th>Email Empresa</th><th>Telefono Empresa</th><th></th></tr>
                        </thead>
                        <tbody>
                            <?php
                                include_once("cargaEmpresa.php");
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
   <!-- Ventana Modal -->
   <div class="modal" id="modalRegistro">
       <div class="modal-content">
           <h4>Alta y Edición de Empresas</h4>
           <br>
           <form id="frm-empresa" method="post" enctype="multipart/form-data" >
              <div class="row">
                   <div class="input-field col s12">
                       <input type="hidden" id="pk" name="pk" value="0">
                       <input type="text" id="clave" name="clave" class="validate">
                       <label for="clave">Rut Empresa:</label>
                   </div>
                   <div class="input-field col s12">
                       <input type="text" id="nom" name="nom" class="validate">
                       <label for="nom">Acronimo Empresa:</label>
                   </div>
                   <div class="input-field col s12">
                      <input type="text" id="credito" name="credito" class="validate">
                      <label for="credito">Direccion Empresa:</label>
                </div>
                <div class="input-field col s12">
                      <input type="text" id="estado" name="estado" class="validate">
                      <label for="estado">Region Empresa:</label>
                </div>
         
             </div>
           </form>
       </div>
       <div class="modal-footer">
           <a id="guardar" class="modal-action waves-effect waves-green btn-flat" >Guardar</a>
       </div>
   </div>
   <?php include_once("../resources/html/footer.php"); ?>
    <script type="text/javascript" src="../js/jquery-3.0.0.min.js"></script>
    <script type="text/javascript" src="../js/materialize.min.js"></script>
    <script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../js/dataTables.materialize.js"></script>
    <script type="text/javascript" src="../js/jquery.validate.min.js"></script>     
    <script type="text/javascript" src="../resources/js/Cursos.js"></script>
    <script type="text/javascript">
    </script> 
</body>
</html>