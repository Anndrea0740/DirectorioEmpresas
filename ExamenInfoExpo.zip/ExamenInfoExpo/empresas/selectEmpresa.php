<?php
    include_once('../Utilerias/db.php');
    $clases = cargaEmpresa();


    foreach ($clases as $tupla )
    {
        $id=$tupla['rutEmpresa'];
        $nom=$tupla['acronimoEmpresa'];
        echo "<option value='$id' >$nom</option>";
    } 
?>