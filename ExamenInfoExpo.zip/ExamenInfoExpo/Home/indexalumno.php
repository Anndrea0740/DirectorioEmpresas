<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="../css/dataTables.materialize.css"/>
    <link type="text/css" rel="stylesheet" href="../css/default.css"/>
    <link type="text/css" rel="stylesheet" href="../css/alumno.css"/>
    <link rel="icon" type="image/x-icon" href="../fonts/favicon.ico" />
</head>
<body>
<?php include_once("../resources/html/headeradmin.php"); ?>


  <div class="container" id="for">
      <h1>Bienvenido a AsesoraTec</h1>
      <div id="tex">
      <p>Ahora puedes subir tus tareas, trabajos de una manera más facil, ademas de recibir asesorias gratis y con la posibilidad de dar las asesorias tu mismo.</p>
      </div>
  </div>

  <?php include_once("../resources/html/footer.php"); ?>
  <script type="text/javascript" src="../js/jquery-3.0.0.min.js"></script>
    <script type="text/javascript" src="../js/materialize.min.js"></script>
    <script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../js/dataTables.materialize.js"></script>
    <script type="text/javascript" src="../js/jquery.validate.min.js"></script>     
    <script type="text/javascript" src="../resources/js/clase.js"></script>
    <script type="text/javascript">    
    </script> 

  </body>
</html>
