<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="../css/dataTables.materialize.css"/>
    <link type="text/css" rel="stylesheet" href="../css/default.css"/>
    <link rel="icon" type="image/x-icon" href="../fonts/favicon.ico" />
</head>
<body>
<?php include_once("../resources/html/headerad.php"); ?>
  <div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center orange-text">AsesorTEC</h1>
      <div class="row center">
        <h5 class="header col s12 light"></h5>
        <h4 class="header col s12 light">Ofrece a tus alumnos y docentes una
         herramienta excelente para facilitar su comunicación en el hambito de Aprendizaje</h5>
      </div>
      <div class="row center">
        <a href="http://materializecss.com/getting-started.html" id="download-button" class="btn-large waves-effect waves-light orange">Iniciar Sesión</a>
      </div>
      <br><br>

    </div>
  </div>

  <div class="container">
    <div class="section">
      <!--   Icon Section   -->
      <div class="row">
        <div class="col s12 m4">
          <div class="icon-block">
            <h2 class="center light-blue-text"><i class="material-icons">flash_on</i></h2>
            <h5 class="center">Misión</h5>

            <p class="light">
              Somos una empresa dedicada al desarrollo y comercialización de aplicaciones, web, móviles, sistemas de gestión de información, y consultoría de solución de datos, proporcionando las tecnologías más innovadoras a medida de los cambios tecnológicos dados en la actualidad, y para cubrir las necesidades, de los clientes, para así de aumentar los beneficios para el cliente, en base al desarrollo de soluciones creativas, aprovechando las nuevas tecnologías, brindando al cliente seguridad y atención en base a sus necesidades y cubriendo sus necesidades futuras.
              </p>
          </div>
        </div>

        <div class="col s12 m4">
          <div class="icon-block">
            <h2 class="center light-blue-text"><i class="material-icons">group</i></h2>
            <h5 class="center">Visión</h5>

            <p class="light">
              Convertirnos en un confidente y amigo para el cliente para lograr cubrir sus necesidades de forma trasparente y eficaz para convertirnos así en un socio de confianza. Para lograr ser una empresa de referencia, que va de la mano con el cambio tecnológico y la sociedad, abriendo paso a nuevos estándares tecnológicos en el desarrollo de los proyectos de la organización, haciéndolo de manera ética y satisfactoria tanto para el cliente como para nosotros como organización.
              </p>
          </div>
        </div>

        <div class="col s12 m4">
          <div class="icon-block">
            <h2 class="center light-blue-text"><i class="material-icons">settings</i></h2>
            <h5 class="center">Los valores construyen a nuestra empresa</h5>

            <p class="light">Como empresa difundimos la responsabilidad, la igualdad, la lealtad, la solidaridad y el amor de nosotros hacia nuestros clientes y para cada uno de los miembros de la organización.</p>
          </div>
        </div>
      </div>

    </div>
    <br><br>
  </div>

  <?php include_once("../resources/html/footer.php"); ?>
  <script type="text/javascript" src="../js/jquery-3.0.0.min.js"></script>
    <script type="text/javascript" src="../js/materialize.min.js"></script>
    <script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../js/dataTables.materialize.js"></script>
    <script type="text/javascript" src="../js/jquery.validate.min.js"></script>     
    <script type="text/javascript" src="../resources/js/clase.js"></script>
    <script type="text/javascript">    
    </script> 

  </body>
</html>
