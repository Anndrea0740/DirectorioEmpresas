<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Menu</title>
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
</head>

<body>

  <div id="container">

  <div id="menu">

    <ul id="slide-out" class="side-nav fixed">
      <li><a href="http://localhost/morir/pruebas/">Inicio</a></li>
      <!-- <li><a href="#!">Second Sidebar Link</a></li> -->
      <li class="no-padding">
        <ul class="collapsible collapsible-accordion">
          <li>
          <a class="collapsible-header">Contenido<i class="material-icons">arrow_drop_down</i></a>
            <div class="collapsible-body">
              <ul>
                <?php 
          include_once("../Utilerias/db.php");
            //echo "<h1>Validando Tu y idsess</h1>" .  $_SESSION["email"]; 
                if  (!isset($_SESSION))
                {
                    session_start();
                    $idSess = session_id();
                }
                        
               // echo "<h1>Validando Tu y idSess</h1>" . $idSess;
                $tu = isset($_SESSION["tu"])?$_SESSION["tu"]:"";
                $correo = isset($_SESSION["email"])?$_SESSION["email"]:"";
                $idsess = "";
                validaSess($correo, $tu, $idsess);
                //echo "<h1>idsess</h1>" . $idsess;
                //echo "<h1>tu</h1>" . $tu;
                if ($idsess == $idSess && $tu == 52)
                {
                    $_SESSION["tu"]=$tu;
                    $_SESSION["email"]=$correo;
                    $_SESSION["ids"]=$idSess;
                    $response['status']= true;
                    echo "<li><a href='http://localhost/morir/clase/'>Clases</a></li>";
                    echo "<li><a href='http://localhost/morir/materia/'>Materia</a></li>";
                    echo "<li><a href='http://localhost/morir/unidad/'>Unidades</a></li>";
                    echo "<li><a href='http://localhost/morir/tema/'>Temas</a></li>";
                    echo "<li><a href='http://localhost/morir/actividad/'>Actividades</a></li>";
                    echo "<li><a href='http://localhost/morir/alumno/'>Alumnos</a></li>";
                    echo "<li><a href='http://localhost/morir/maestro/'>Maestros</a></li>";
                    echo "<li><a href='http://localhost/morir/lista/'>Listas</a></li>";
                }else
                if ($idsess == $idSess && $tu == 1)
                {
                    $_SESSION["tu"]=$tu;
                    $_SESSION["email"]=$correo;
                    $_SESSION["ids"]=$idSess;
                    $response['status']= true;
                    echo "<li><a href='http://localhost/morir/Docente/'>Docente</a></li>";
                }else
                if ($idsess == $idSess && $tu == 2)
                {
                    $_SESSION["tu"]=$tu;
                    $_SESSION["email"]=$correo;
                    $_SESSION["ids"]=$idSess;
                    $response['status']= true;
                    echo "<li><a href='http://localhost/morir/Alumn/'>Alumno</a></li>";
                }
    ?>

              </ul>
            </div>
          </li>
        </ul>
      </li>
    </ul>
  </div>
    
</div>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
