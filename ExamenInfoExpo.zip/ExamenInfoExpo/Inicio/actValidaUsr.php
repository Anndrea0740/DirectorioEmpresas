<?php
     include_once("../Utilerias/db.php");
     $post = $_POST; // Recibe los parametros
      
     if  (!isset($_SESSION))
        session_start();
     $idSess = session_id(); // Obtenemos el numero de session
     $res = validaUsr($post,$idSess);
     if ($res == "1" || $res == "2" || $res == "52"){
            $_SESSION["tu"]=$res;
            $_SESSION["email"]=$post['correo'];
            $_SESSION["ids"]=$idSess;
            $response['status']= true;
            $response['data']="http://localhost/morir/Home";
      }
      else{
            $response['status']= false;
            $response['data']=$post;
      }
      echo json_encode($response);
?>