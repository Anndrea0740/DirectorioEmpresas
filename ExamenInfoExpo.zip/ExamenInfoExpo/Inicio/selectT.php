<?php
    include_once('../Utilerias/db.php');
    $clases = cargaTipou();


    foreach ($clases as $tupla )
    {
        $id=$tupla['idt'];
        $nom=$tupla['nombret'];
        echo "<option value='$id' >$nom</option>";
    } 
?>