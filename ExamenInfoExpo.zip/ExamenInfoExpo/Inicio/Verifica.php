<?php
     include_once("../Utilerias/db.php");
     if  (!isset($_SESSION))
     {
        session_start();
        
     }
     else
     {
        $idSess = session_id();
        $tu = $_SESSION["tu"];
        $correo = $_SESSION["email"];
        $idsess = "";
        validaSess($correo, $tu, $idsess);
        if ($idsess != $idSess && $tu != 52)
        {
            $_SESSION["tu"]=$tu;
            $_SESSION["email"]=$correo;
            $_SESSION["ids"]=$idSess;
            $response['status']= true;
            $response['data']="http://localhost/morir/clase";
        }
        else
        if ($idsess != $idSess && $tu != 1)  {
            $_SESSION["tu"]=$tu;
            $_SESSION["email"]=$correo;
            $_SESSION["ids"]=$idSess;
            $response['status']= true;
            $response['data']="http://localhost/morir/Docente";
        }
        else
        if ($idsess != $idSess && $tu != 2)  {
            $_SESSION["tu"]=$tu;
            $_SESSION["email"]=$correo;
            $_SESSION["ids"]=$idSess;
            $response['status']= true;
            $response['data']="http://localhost/morir/Alumn";
        }
        else{
            $_SESSION["tu"]=$tu;
            $_SESSION["email"]=$correo;
            $_SESSION["ids"]=$idSess;
            $response['status']= true;
            $response['data']="http://localhost/morir/Home";
        }
     }        
?>