<header>
<nav>
    <!-- Menú para cuando se despliega la página en un dispositivo grande   -->
    <div class="nav-wrapper">
      <a href="http://localhost/morir/home/" class="brand-logo">Logo</a>
      <a href="#" data-target="mobile-demo" 
         class="sidenav-trigger"><i class="material-icons">
         menu</i></a>
      <ul class="right hide-on-med-and-down">
      <?php include_once("../resources/html/header.php");
          include_once("../Utilerias/db.php");
                if  (!isset($_SESSION))
                {
                    session_start();
                    $idSess = session_id();
                }
                $tu = isset($_SESSION["tu"])?$_SESSION["tu"]:"";
                $correo = isset($_SESSION["email"])?$_SESSION["email"]:"";
                $idsess = "";
                validaSess($correo, $tu, $idsess);
                if ($idsess == $idSess && $tu == 52)
                {
                    $_SESSION["tu"]=$tu;
                    $_SESSION["email"]=$correo;
                    $_SESSION["ids"]=$idSess;
                    $response['status']= true;
                    echo "<li><a href='http://localhost/ExamenInfoExpo/empresas/'>Empresas</a></li>";
                }else
                if ($idsess == $idSess && $tu == 1)
                {
                    $_SESSION["tu"]=$tu;
                    $_SESSION["email"]=$correo;
                    $_SESSION["ids"]=$idSess;
                    $response['status']= true;
                    echo "<li><a href='http://localhost/ExamenInfoExpo/Home/'>Index.php</a></li>";
                }
    ?>
        <li><a href="badges.html">Components</a></li>
        <li><a href="collapsible.html">Javascript</a></li>
        <li><a href="mobile.html">Mobile</a></li>
      </ul>
    </div>
  </nav>
<!-- Menú para cuando se despliega la página en un dispositivo móvil   -->
  <ul class="sidenav" id="mobile-demo">
  <li><a href='http://localhost/ExamenInfoExpo/empresas/'>Empresas</a></li>
  </ul>
</header>