<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="../css/dataTables.materialize.css"/>
    <link type="text/css" rel="stylesheet" href="../css/default.css"/>
    <link rel="icon" type="image/x-icon" href="../fonts/favicon.ico" />

  </head>
  <body>
  <header>

<nav class="light-blue lighten-1" role="navigation">
     <!-- Menú para cuando se despliega la página en un dispositivo grande   -->
     <div class="nav-wrapper">
      <a href="http://localhost/morir/home/" class="brand-logo">Logo</a>
      <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="http://localhost/morir/home/indexadmin.php">Inicio</a></li>
        <li><a href="http://localhost/morir/Curso/alumno.php">Unidades</a></li>
        <li><a href="http://localhost/morir/curso/maestro.php">Temas</a></li>
        <li><a href="http://localhost/morir/curso/materia.php">Actividades</a></li>
        <li><a href="http://localhost/morir/Curso/clase.php">Lista</a></li>
        <li><a href="http://localhost/morir/Home/indexadmin.php">Salir</a></li>
      </ul>
    </div>
  </nav>
<!-- Menú para cuando se despliega la página en un dispositivo móvil   -->
  <ul class="sidenav" id="mobile-demo">
    <li><a href="http://localhost/morir/home/indexprin.php">Inicio</a></li>
    <li><a href="badges.html">Registrar Institución</a></li>
  </ul>
</header>
  </body>
</html>