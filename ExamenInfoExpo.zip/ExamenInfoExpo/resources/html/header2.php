<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Menu</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection"/>
        <link type="text/css" rel="stylesheet" href="../css/dataTables.materialize.css"/>
        <link type="text/css" rel="stylesheet" href="../css/default.css"/>
        <link type="text/css" rel="stylesheet" href="../css/clase.css"/>
        <link rel="icon" type="image/x-icon" href="../fonts/favicon.ico" />

    </head>
    <body>
        <nav>
            <div class="nav-wrapper">
               <div class="container">
                   <a href="#">Oston Code</a>
               </div>
            </div>
        </nav>


    <script type="text/javascript" src="../js/jquery-3.0.0.min.js"></script>
    <script type="text/javascript" src="../js/materialize.min.js"></script>
    <script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../js/dataTables.materialize.js"></script>
    <script type="text/javascript" src="../js/jquery.validate.min.js"></script>     
    <script type="text/javascript" src="../resources/js/clase.js"></script>
    <script type="text/javascript">
        
    </script> 
    </body>
</html>