<ul style="transform: translateX(0px);" class="side-nav" id="mobile-menu">
  <img src="images/costum_logos/logo3.png" class="custom-logo">
  <div class="divider"></div>
  <a href="index.php" class="waves-effect waves-light">Albums
    <i class="material-icons left notranslate">collections</i>
  </a>
  <a href="?page=settings" class="waves-effect waves-light">Settings
    <i class="material-icons left notranslate">settings</i></a>
  <a class="waves-effect waves-light red-text text-lighten-1" href="index.php?logout">Logout
    <i class="material-icons left notranslate">power_settings_new</i>
  </a>
</ul>