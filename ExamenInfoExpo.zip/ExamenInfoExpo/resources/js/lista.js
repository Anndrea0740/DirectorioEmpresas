$(init);
var table = null;
var plataforma = null;

function init(){
    // Inicializa el NavBar
    $(document).ready(function(){
        $('.sidenav').sidenav();
    });

    // Configuración del DataTable
    table = $('#cur').DataTable({"aLengthMenu": 
           [[10,25,50,75,100],[10,25,50,75,100]],
           "iDisplaylength":15});

    //Llena el arrelo de cursos con la Información BD
    cargaLista();      

    //Iniciliza la ventana Modal y la Validación
    $("#modalRegistro").modal();
    validateForm();

    // Clic del boton circular Agregar
    $("#add-record").on("click",function(){
        $("#modalRegistro").modal('open');
        $("#calificacion").focus();
    });
    
    // clic del boton de guardar
    $('#guardar').on("click",function(){
        $('#frm-plataforma').submit();
    });
    // Clic del boton circular Imprimir
    $("#print-record").on("click",function(){
        document.location.href = "http://localhost/morir/TCPDF/Reportes/ReporteLista.php"
    });
    // clic de Borrar
    $(document).on("click", '.delete', function(){
        var id = $(this).attr("id-record");
        deleteData(id);
    });

   
  
    $(document).on("click", '.edit', function(){
        var id = $(this).attr("id-record");
        $("#clave").val(plataforma[id]["idregalumno"]).next().addClass('active');
        $("#mat").val(plataforma[id]["clavemateria"]).next().addClass('active');
        $("#na").val(plataforma[id]["idactividad"]).next().addClass('active');
        $("#calificacion").val(plataforma[id]["calificacion"]).next().addClass('active');
        $("#estado").val(plataforma[id]["estado"]).next().addClass('active');
        $("#pk").val(id);
        $("#modalRegistro").modal('open');
        $("#clave").focus();
    });
}

function validateForm(){
    $('#frm-plataforma').validate({
        rules: {
          //  clave:{required:true, number:true},
          //  mat:{required:true,minlength:11, maxlength:11},
          //  na:{required:true, number:true},
            calificacion:{required:true, number:true},
            estado:{required:true, number:true},  
        },
        messages: {
           // clave:{required:"Debes ingresar un costo válido",number:"Este campo debe ser numérico"}, 
           // mat:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 11 caracteres", maxlength:"No puedes ingresar más de 11 caracteres"},
           // na:{required:"Debes ingresar un costo válido",number:"Este campo debe ser numérico"},
            calificacion:{required:"Debes ingresar una calificación válido",number:"Este campo debe ser numérico"},
            estado:{required:"Debes ingresar un estado válido",number:"Este campo debe ser numérico"},
          },
        errorElement: "div",
        errorClass: "invalid",
        errorPlacement: function(error, element){
            error.insertAfter(element)                
        },
        submitHandler: function(form){
            saveData();
        }
    });
}


function cargaLista(){
    var parametros = "";
    $.ajax({
        type:"post",
        url:"llenaLista.php",
        dataType:'json',
        data:parametros,
        success:function(respuesta){
            if (respuesta['status']){
                plataforma=respuesta['data'];
            } else{
                plataforma=null;
            }
        }
    });
}

function saveData(){
    var id = $("#pk").val(); 
    var boton = "";
    var sURL = "";
    if (id == "0")
    {
        sURL="agregaLista.php"
    }else{
        sURL = "actualizaLista.php"
    }

    parametros = new FormData($("#frm-plataforma")[0]);
    alert(parametros);
    $.ajax({
        type:"post",
        url:sURL,
        contentType: false,
        processData:false,
        dataType:'json',
        data: parametros,

        success: function(respuesta){
            alert(respuesta['status']);
            if (respuesta['status']){
                var clave = $('select[name="clave"] option:selected').text();
                var mate = $('select[name="mat"] option:selected').text();
                var na = $('select[name="na"] option:selected').text();
                $("#pk").val('0');
              //  $("#clave").val('0');
               // $("#mat").val('');
               // $("#na").val('0');
                $("#calificacion").val('0');
                $("#estado").val('0');
                $("#modalRegistro").modal('close');
                M.toast({html: 'Lista Guardada', classes: 'rounded', displayLength: 4000});
                if (id == "0"){ // Insert
                    actualizaDataTable(respuesta['data'],'insert',clave,mate,na)
                }
                else // Update
                {
                    actualizaDataTable(respuesta['data'],'delete')
                    actualizaDataTable(respuesta['data'],'insert',clave,mate,na)
                }
            }
            else{
                M.toast({html: 'Error al Agregar Lista', classes: 'rounded', displayLength: 4000});
            }
        }
    });
}

function deleteData(id){
    var boton = "&boton=Borrar";
    var parametros='pk='+ id + boton;
    $.ajax({
        type:"post",
        url:"eliminaLista.php",
        dataType:'json',
        data:parametros,
        success: function(respuesta){
            if (respuesta['status']){
                M.toast({html: 'Lista Eliminado', classes: 'rounded', displayLength: 4000});
                actualizaDataTable(respuesta['data'],'delete')
            }
            else{
                M.toast({html: 'Error al Eliminar Lista', classes: 'rounded', displayLength: 4000});
            }
        }
    });
}




function actualizaDataTable(data, action,clave,mate,na) {
    if (action === 'insert'){
        var row = table.row.add([
            clave,
            mate,
            na,
            data.calificacion,
            data.estado,
            
            '<i class="material-icons edit" id-record="' + data.pk + '">create</i>' +
            '<i class="material-icons delete" id-record="' + data.pk +  '">delete_forever</i>'
        ]).draw().node();
        $(row).attr('id',data.pk);
        //Agrega el registro al arreglo cursos
        plataforma[data.pk]={
            "idlista":     data.pk,
            "idregalumno":  data.clave,
            "clavemateria": data.mat,
            "numeroactividad": data.na,
            "calificacion":  data.calificacion,
            "estado":  data.estado,
        }
    } 
    else if (action === 'delete'){
        table.row('#'+ data.pk).remove().draw();   
    }
}

