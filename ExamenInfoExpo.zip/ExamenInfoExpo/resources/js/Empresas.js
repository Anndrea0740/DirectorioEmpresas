$(init);
var table = null;
var cursos = null;

function init(){
    // Inicializa el NavBar
    $(document).ready(function(){
        $('.sidenav').sidenav();
    });

    // Configuración del DataTable
    table = $('#cur').DataTable({"aLengthMenu": 
           [[10,25,50,75,100],[10,25,50,75,100]],
           "iDisplaylength":15});

    //Llena el arrelo de cursos con la Información BD
    cargaEmpresa();      

    //Iniciliza la ventana Modal y la Validación
    $("#modalRegistro").modal();
    validateForm();
   
    // Clic del boton circular Agregar
    $("#add-record").on("click",function(){
        $("#modalRegistro").modal('open');
        $("#clave").focus();
    });
    
    // clic del boton de guardar
    $('#guardar').on("click",function(){
        $('#frm-empresa').submit();
    });

    // clic de Borrar
    $(document).on("click", '.delete', function(){
        var id = $(this).attr("id-record");
        deleteData(id);
    });

    // clic de Editar
    $(document).on("click", '.edit', function(){
        var id = $(this).attr("id-record");
        $("#clave").val(cursos[id]["clavemateria"]).next().addClass('active');
        $("#nom").val(cursos[id]["nombremateria"]).next().addClass('active');
        $("#credito").val(cursos[id]["creditomateria"]).next().addClass('active');
        $("#estado").val(cursos[id]["estado"]).next().addClass('active');
        $("#pk").val(id);
        $("#modalRegistro").modal('open');
        $("#clave").focus();
    });

       
}



function validateForm(){
    $('#frm-empresa').validate({
        rules: {
            clave:{required:true,minlength:8, maxlength:60},
            nom:{required:true, minlength:8, maxlength:126},
            credito:{required:true, number:true},   
            estado:{required:true, number:true},    
        },
        messages: {
            clave:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 60 caracteres"},
            nom:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 126 caracteres"},
            credito:{required:"Debes ingresar un costo válido",number:"Este campo debe ser numérico"},             
            estado:{required:"Debes ingresar un costo válido",number:"Este campo debe ser numérico"},             
             },
        errorElement: "div",
        errorClass: "invalid",
        errorPlacement: function(error, element){
            error.insertAfter(element)                
        },
        submitHandler: function(form){
            saveData();
        }
    });
}


function cargaEmpresa(){
    var parametros = "";
    $.ajax({
        type:"post",
        url:"llenaArrayEmpresa.php",
        dataType:'json',
        data:parametros,
        success:function(respuesta){
            if (respuesta['status']){
                cursos=respuesta['data'];
            } else{
                cursos=null;
            }
        }
    });
}

function saveData(){
    var id = $("#pk").val(); 
    var boton = "";
    var sURL = "";
    if (id == "0")
    {
        sURL="actEmpresaAgregar.php"
    }else{
        sURL = "actEmpresaActualizar.php"
    }

    parametros = new FormData($("#frm-empresa")[0]);
    alert(parametros);
    $.ajax({
        type:"post",
        url:sURL,
        contentType: false,
        processData:false,
        dataType:'json',
        data: parametros,
        success: function(respuesta){
            alert(respuesta['status']);
            if (respuesta['status']){
                $("#pk").val('0');
                $("#clave").val('');
                $("#nom").val('');
                $("#credito").val('0');
                $("#estado").val('');
                $("#modalRegistro").modal('close');
                M.toast({html: 'Curso Guardado', classes: 'rounded', displayLength: 4000});
                if (id == "0"){ // Insert
                    actualizaDataTable(respuesta['data'],'insert')
                }
                else // Update
                {
                    actualizaDataTable(respuesta['data'],'delete')
                    actualizaDataTable(respuesta['data'],'insert')
                }
            }
            else{
                M.toast({html: 'Error al Agregar Empresa', classes: 'rounded', displayLength: 4000});
            }
        }
    });
}

function deleteData(id){
    var boton = "&boton=Borrar";
    var parametros='pk='+ id + boton;
    $.ajax({
        type:"post",
        url:"actEmpresaEliminar.php",
        dataType:'json',
        data:parametros,
        success: function(respuesta){
            if (respuesta['status']){
                M.toast({html: 'Empresa Eliminada', classes: 'rounded', displayLength: 4000});
                actualizaDataTable(respuesta['data'],'delete')
            }
            else{
                M.toast({html: 'Error al Eliminar Empresa', classes: 'rounded', displayLength: 4000});
            }
        }
    });
}

function actualizaDataTable(data, action) {
    if (action === 'insert'){
        var row = table.row.add([
            data.clave,
            data.nom,
            data.credito,
            data.estado,
            '<i class="material-icons edit" id-record="' + data.pk + '">create</i>' +
            '<i class="material-icons delete" id-record="' + data.pk +  '">delete_forever</i>'
        ]).draw().node();
        $(row).attr('id',data.pk);
        //Agrega el registro al arreglo cursos
        cursos[data.pk]={
            "idmateria":     data.pk,
            "clavemateria":  data.clave,
            "nombremateria": data.nom,
            "creditomateria":data.credito,
            "estado":        data.estado,
        }
    } 
    else if (action === 'delete'){
        table.row('#'+ data.pk).remove().draw();   
    }
}

