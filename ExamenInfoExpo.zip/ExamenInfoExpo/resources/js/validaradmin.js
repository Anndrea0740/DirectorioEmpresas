$(init)
function init(){
    $("#btn").on("click", function(){
        $('#formulario').validate({

            rules: {
                nombre:{required:true,minlength:8, maxlength:160},
                cedula:{required:true, number:true, maxlength:8}, 
                institucion:{required:true,minlength:8, maxlength:160}, 
                clave:{required:true, number:true, maxlength:20}, 
                correo:{required:true, minlength:8, maxlength:126}, 
                pass1:{required:true,minlength:8, maxlength:160},
                pass2:{required:true,minlength:8, maxlength:160},
                terminos:{required:true},    
            },
            messages: {
                nombre:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 60 caracteres"},
                cedula:{required:"Debes ingresar un costo válido",number:"Este campo debe ser numérico",maxlength:"No puedes ingresar mas de 8 caracteres"},   
                institucion:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 126 caracteres"},
                clave:{required:"Debes ingresar un costo válido",number:"Este campo debe ser numérico",maxlength:"No puedes ingresar mas de 8 caracteres"},   
                correo:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 120 caracteres"},
                pass1:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 126 caracteres"},
                pass2:{required:"No puedes dejar este campo vacío",minlength:"Debes ingresar al menos 8 caracteres", maxlength:"No puedes ingresar más de 126 caracteres"},
                   
            },
            errorElement:"div",
            errorClass:"invalid",
            errorPlacement:function(error, element){
                error.insertAfter(element)
            }, 
            submitHandler:function(form){
                saveData();
            }
            
        });
    });
}
    function saveData(){
    alert('El Formulario Es Valido Y Guardando...');
}