<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="css/dataTables.materialize.css"/>
    <link type="text/css" rel="stylesheet" href="css/default.css"/>
    <link rel="icon" type="image/x-icon" href="fonts/favicon.ico" />
    <link type="text/css" rel="stylesheet" href="css/masonry-docs.css"/>
    </head>

    <header>
  <nav>
    <!-- Menú para cuando se despliega la página en un dispositivo grande  
    <div class="nav-wrapper">
      <a href="http://localhost/Aproyectoc/AProyectoX/home/" class="brand-logo">Logo</a>
      <a href="#" data-target="mobile-demo" 
         class="sidenav-trigger"><i class="material-icons">
         menu</i></a>
      <ul class="right hide-on-med-and-down">
      <li><a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/index.php">Principal</a></li>
        <li><a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/categoria.php">Categorias</a></li>
        <li><a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/marca.php">Marcas</a></li>
        <li><a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/productos.php">Productos</a></li>
      </ul>
    </div> -->
    <div class="site-nav">
    <div class="container">
      <ol class="site-nav__list">
        <li class="site-nav__item site-nav__item--homepage">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/index.php">CatalogShop</a></li>
          <li class="site-nav__item site-nav__item--layout">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/registro.php">Registrarse</a></li>
          <li class="site-nav__item site-nav__item--layout">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/admin.php">Iniciar Secion</a></li>
        
        </ol>
    </div>
  </div>
  </nav>
  </header>
    <body>
    <div class="contenedor-formulario">
  <div class="wrap">
    <form action="" class="formulario" name="formulario_registro" method="get">
      <div>
        <div class="input-group">
          <input type="text" id="nombre" name="nombre">
          <label class="label" for="nombre">Nombre:</label>
        </div>
        <div class="input-group">
          <input type="email" id="correo" name="correo">
          <label class="label" for="correo">Correo:</label>
        </div>
        <div class="input-group">
          <input type="password" id="pass" name="pass">
          <label class="label" for="pass">Contraseña:</label>
        </div>
        <div class="input-group">
          <input type="password" id="pass2" name="pass2">
          <label class="label" for="pass2">Repetir Contraseña:</label>
        </div>
        <div class="input-group radio">
          <input type="radio" name="sexo" id="hombre" value="Hombre">
          <label for="hombre">Hombre</label>
          <input type="radio" name="sexo" id="mujer" value="Mujer">
          <label for="mujer">Mujer</label>
        </div>
        <div class="input-group checkbox">
          <input type="checkbox" name="terminos" id="terminos" value="true">
          <label for="terminos">Acepto los Terminos y Condiciones</label>
        </div>

        <input type="submit" id="btn-submit" value="Enviar">
      </div>
    </form>
  </div>
</div>
<div class="site-footer">
    <div class="container">
      <div class="showcase">

        <ul class="showcase-item-list">
            <li class="showcase-item">
              <a class="showcase-item__link" href="https://isotope.metafizzy.co">
                <div class="showcase-item__image">
                   
                </div>
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Isotope</h3>
                  <p class="showcase-item__description">Filter &amp; sort magical layouts</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="https://infinite-scroll.com">
             
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Infinite Scroll</h3>
                  <p class="showcase-item__description">Automatically add next page</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="https://flickity.metafizzy.co">
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Flickity</h3>
                  <p class="showcase-item__description">Touch, responsive, flickable carousels</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="http://fizzy.school">
                <div class="showcase-item__image">
                  
                </div>
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Fizzy School</h3>
                  <p class="showcase-item__description">Lessons in JavaScript for jQuery newbies</p>
                </div>
              </a>
            </li>

        </ul>

      </div>

    </div>
  </div>

    <script type="text/javascript" src="js/jquery-3.0.0.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/dataTables.materialize.js"></script>
    <script type="text/javascript" src="js/jquery.validate.min.js"></script>     
    <script type="text/javascript" src="resources/js/mar.js"></script>
    <script type="text/javascript">
     <script type="text/javascript" src="js/masonry-docs.min"></script>   
        
    </script> 
    </body>
</html>