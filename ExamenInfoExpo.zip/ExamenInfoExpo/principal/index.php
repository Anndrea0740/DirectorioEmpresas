<!doctype html>
<html class="export" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width">
  <meta name="description" content="Cascading grid layout library">

  <title>Classroom Cloud</title>

    <link rel="stylesheet" href="css/masonry-docs.css" media="screen">
    <link rel="stylesheet" href="css/edit.css" media="screen">

</head>
<body class="page--" data-page="">
  <header>
  <nav>
   
    <div class="site-nav">
    <div class="container">
      <ol class="site-nav__list">
        <li class="site-nav__item site-nav__item--homepage">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/index.php">Classroom Cloud</a></li>
          <li class="site-nav__item site-nav__item--layout">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/admin.php">Iniciar Secion</a></li>
        
        </ol>
    </div>
  </div>
  </nav>
  </header>

    <div class="hero" data-js="hero">
      <div class="container" >
      <div class="row" id="nop">
        
          <div class="hero-grid__grid-sizer"></div>

          <div class="hero-grid__item hero-grid__item--texty hero-grid__item--width3">
            <h1 class="hero__title">Classroom Cloud</h1>
            <p class="hero__tagline">De Plataforma de Aprendisaje Virtual</p>
          </div>

          <div class="hero-grid__item hero-grid__item--texty hero-grid__item--width2">
            <h2 class="hero__what-is-title">Encuentra todo lo que quieras</h2>
            <p class="hero__what-is-description">CatalogShop | Catalogo online de Moda con amplia colección de Zapatos, Ropa, Accesorios y más para toda la familia.</p>
          </div>

        
        </div>
        <div class="galeria">
        <div class="col l4 m6 s12 gallery-item gallery-expand gallery-filter bigbang">
  <div class="gallery-curve-wrapper">
    <a class="gallery-cover gray">
      <img class="responsive-img" src="tecnm.jpeg" alt="placeholder">
    </a>
    <div class="gallery-header">
      <span>Gallery Link</span>
    </div>
    <div class="gallery-body">
      <div class="title-wrapper">
        <h3>Grapefruit</h3>
        <span class="price">$14.99</span>
      </div>
    </div>
    <div class="gallery-action">
      <a class="btn-floating btn-large waves-effect waves-light">
        <i class="material-icons">favorite
      </i></a>
    </div>
  </div>
</div>
        </div>
      </div>


    

    </div>


  <div class="site-footer">
    <div class="container">
      <div class="showcase">

        <ul class="showcase-item-list">
            <li class="showcase-item">
              <a class="showcase-item__link" href="https://isotope.metafizzy.co">
                <div class="showcase-item__image">
                   
                </div>
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Isotope</h3>
                  <p class="showcase-item__description">Filter &amp; sort magical layouts</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="https://infinite-scroll.com">
             
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Infinite Scroll</h3>
                  <p class="showcase-item__description">Automatically add next page</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="https://flickity.metafizzy.co">
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Flickity</h3>
                  <p class="showcase-item__description">Touch, responsive, flickable carousels</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="http://fizzy.school">
                <div class="showcase-item__image">
                  
                </div>
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Fizzy School</h3>
                  <p class="showcase-item__description">Lessons in JavaScript for jQuery newbies</p>
                </div>
              </a>
            </li>

        </ul>

      </div>

    </div>
  </div>
<script>
// Open
$('.gallery-expand').galleryExpand('open');

// Close
$('.gallery-expand').galleryExpand('close');
</script>
  <script src="js/masonry-docs.min.js?2"></script>


</body>
</html>
