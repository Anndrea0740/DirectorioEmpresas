<!doctype html>
<html class="export" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width">
  <meta name="description" content="Cascading grid layout library">

  <title>CatalogShop</title>

    <link rel="stylesheet" href="css/masonry-docs.css?3" media="screen">
    <link rel="stylesheet" href="css/edit.css" media="screen">

</head>
<body class="page--" data-page="">
  <div class="site-nav">
    <div class="container">
      <ol class="site-nav__list">
        <li class="site-nav__item site-nav__item--homepage">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/principal/">PaticoShop</a></li>
        <li class="site-nav__item site-nav__item--layout">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/categoria.php">Categoria</a></li>
        <li class="site-nav__item site-nav__item--options">
          <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/marca.php">Marca</a></li>
          <li class="site-nav__item site-nav__item--options">
            <a href="http://localhost/catalogshop1/aproyectoc/AProyectoX/catalogo/productos.php">Producto</a></li>
      </ol>
    </div>
  </div>

    <div class="hero" data-js="hero">
      <div class="container" >
      <div class="row" id="nop">
        
          <div class="hero-grid__grid-sizer"></div>

          <div class="hero-grid__item hero-grid__item--texty hero-grid__item--width3">
            <h1 class="hero__title">CatalogShop</h1>
            <p class="hero__tagline">De PaticoShop</p>
          </div>

          <div class="hero-grid__item hero-grid__item--texty hero-grid__item--width2">
            <h2 class="hero__what-is-title">Bienvenido</h2>
            <p class="hero__what-is-description">Usted a Iniciado sesión como administrador, realize los cambios necesarios</p>
          </div>

        
        </div>
      </div>

    </div>


  <div class="site-footer">
    <div class="container">
      <div class="showcase">

        <ul class="showcase-item-list">
            <li class="showcase-item">
              <a class="showcase-item__link" href="https://isotope.metafizzy.co">
                <div class="showcase-item__image">
                   
                </div>
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Isotope</h3>
                  <p class="showcase-item__description">Filter &amp; sort magical layouts</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="https://infinite-scroll.com">
             
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Infinite Scroll</h3>
                  <p class="showcase-item__description">Automatically add next page</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="https://flickity.metafizzy.co">
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Flickity</h3>
                  <p class="showcase-item__description">Touch, responsive, flickable carousels</p>
                </div>
              </a>
            </li>

            <li class="showcase-item">
              <a class="showcase-item__link" href="http://fizzy.school">
                <div class="showcase-item__image">
                  
                </div>
                <div class="showcase-item__text">
                  <h3 class="showcase-item__title">Fizzy School</h3>
                  <p class="showcase-item__description">Lessons in JavaScript for jQuery newbies</p>
                </div>
              </a>
            </li>

        </ul>

      </div>

    </div>
  </div>

  <script src="js/masonry-docs.min.js?2"></script>


</body>
</html>
