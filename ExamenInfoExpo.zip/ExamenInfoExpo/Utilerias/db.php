<?php
try{
    //Guadalupe Andrea Cuarenta Juarez
    //conexion a la base de datos alojada en PostgreSQL
        $Cn = new PDO('pgsql:host=localhost;port=5432;dbname=directorioEmpresa;user=postgres;password=1234');
        $Cn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $Cn->exec("SET CLIENT_ENCODING TO 'UTF8';");
}catch(Exception $e){
    die("Error: " . $e->GetMessage());
}

// Función para ejecutar consultas SELECT
function Consulta($query)
{
    global $Cn;
    try{    
        $result =$Cn->query($query);
        $resultado = $result->fetchAll(PDO::FETCH_ASSOC); 
        $result->closeCursor();
        return $resultado;
    }catch(Exception $e){
        die("Error en la LIN: " . $e->getLine() . ", MSG: " . $e->GetMessage());
    }
}

// Función que recibe un insert y regresa el consecutivo que le genero
function EjecutaConsecutivo($sentencia){
    global $Cn;
    try {
        $result = $Cn->query($sentencia);
        $resultado = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $resultado[0]['idmateria'];
    } catch (Exception $e) {
        die("Error en la linea: " + $e->getLine() + 
        " MSG: " + $e->GetMessage());
        return 0;
    }
}

function Ejecuta ($sentencia){
    global $Cn;
    try {
        $result = $Cn->query($sentencia);
        $result->closeCursor();
        return 1; 
    } catch (Exception $e) {
        return 0;
    }
}

//--------------Funcion consulta select a empresas----------------------------------------------
function cargaEmpresa(){
    $query = 'SELECT idEmpresa, rutEmpresa, acronimoEmpresa, direccionEmpresa, regionEmpresa, ciudadEmpresa, emailEmpresa, telefonoEmpresa FROM "directorio"."empresa" ORDER BY rutEmpresa';
    return Consulta($query);
}

//-------------Funcion agregar de empresas----------------------    
function agregaEmpresa($post){
    $rutEmpresa = $post["rutEmpresa"];
    $acronimoEmpresa = $post["acronimoEmpresa"];
    $direccionEmpresa = $post["direccionEmpresa"];
    $regionEmpresa = $post["regionEmpresa"];
    $ciudadEmpresa = $post["ciudadEmpresa"];
    $emailEmpresa = $post["emailEmpresa"];
    $telefonoEmpresa = $post["telefonoEmpresa"];
    $sentencia = 'INSERT INTO "directorio".empresa(rutEmpresa, acronimoEmpresa, direccionEmpresa,regionEmpresa,ciudadEmpresa,emailEmpresa,telefonoEmpresa)' . 
                 "values('$rutEmpresa','$acronimoEmpresa','$direccionEmpresa','$regionEmpresa','$ciudadEmpresa','$emailEmpresa','$telefonoEmpresa') RETURNING rutEmpresa";
    return EjecutaConsecutivo($sentencia);
}
function actualizaEmpresa($post){
    $idEmpresa = $post["idEmpresa"];
    $rutEmpresa = $post["rutEmpresa"];
    $acronimoEmpresa = $post["acronimoEmpresa"];
    $direccionEmpresa = $post["direccionEmpresa"];
    $regionEmpresa = $post["regionEmpresa"];
    $ciudadEmpresa = $post["ciudadEmpresa"];
    $emailEmpresa = $post["emailEmpresa"];
    $telefonoEmpresa = $post["telefonoEmpresa"];
    $sentencia = 'UPDATE "directorio".empresa SET ' . "rutEmpresa='$rutEmpresa', acronimoEmpresa='$acronimoEmpresa', 
    direccionEmpresa='$direccionEmpresa',regionEmpresa=$regionEmpresa,ciudadEmpresa='$ciudadEmpresa',emailEmpresa='$emailEmpresa',
    telefonoEmpresa=$telefonoEmpresa WHERE idEmpresa=$idEmpresa"; 
    return Ejecuta($sentencia);
}
function borraEmpresa($post){
    $idEmpresa = $post["idEmpresa"];
    $sentencia = 'DELETE FROM "directorio".empresa WHERE idEmpresa=' . $idEmpresa;
    return Ejecuta($sentencia);
}
//proceso de seguridad validar usuarios
function registraUsr($post,$ids)
{
    $emailusr = $post["emailusr"];
    $nombreusr = $post["nombreusr"];
    $usuariousr = $post["usuariousr"];
    $pwdusr = $post["pwdusr"];
    $pwdEnc = password_hash($pwdusr, PASSWORD_DEFAULT);
    $sql = 'INSERT INTO "sesion".registro(emailusr,nombreusr,pwdusr,usuariousr,idsession)' . 
    "values('$emailusr','$nombreusr','$pwdusr',$usuariousr,'$ids')";
    return Ejecuta($sql);
}

function validaUsr($post,$idSess)
{
    $emailusr = $post["emailusr"];
    $pwdusr = $post["pwdusr"];
    $sql = 'SELECT pwdusr,usuariousr FROM "sesion".registro  WHERE emailusr like ' . "'" . $emailusr . "'";
    $res = Consulta($sql);
    $pwdEnc = "";
    $tipo = 0;
    foreach ($res as $tupla )
    {
        $pwdEnc = $tupla['pwdusr'];
        $tipo = $tupla['usuariousr'];
    }
    if (password_verify($contra, $pwdEnc) )
    {   
        $sql = 'UPDATE "sesion".registro SET ' . "idsession='$idSess' WHERE emailusr like'$emailusr'";
        if (Ejecuta($sql))
            return $tipo;
        else
            return 0;
    }
    else{
        return 0;
    }
}

function validaSess(&$correo, &$tu, &$idsess){
    $correo = $correo;
    $sql = 'SELECT idsession,usuariousr FROM "sesion".registro  WHERE emailusr like ' . "'" . $emailusr . "'";
    $res = Consulta($sql);
    $tipo = 0;
    foreach ($res as $tupla )
    {
        $idsess = $tupla['idsession'];
        $tu = $tupla['usuariousr'];
    }   
    return 0;
}
